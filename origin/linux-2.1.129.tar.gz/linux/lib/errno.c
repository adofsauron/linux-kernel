/*
 *  linux/lib/errno.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 */

int errno;
